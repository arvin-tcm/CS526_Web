<!DOCTYPE html>
<?php
$ice = isset($_POST['ice']);
$lemon = isset($_POST['lemon']);
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="get_checkbox_data.php" method="post">
            <input type="checkbox" name="ice" checked="checked">Add ice<br>
            <input type="checkbox" name="lemon" value="International">Add lemon<br>
            <input type="submit" value="Submit" /><br>
        </form>
        <hr>
        <h2>You have selected:</h2>
        <ul>
            <li><?php echo 'Ice: '.$ice; ?></li>
            <li><?php echo 'Lemon: '.$lemon; ?></li>
        </ul>
    </body>
</html>
