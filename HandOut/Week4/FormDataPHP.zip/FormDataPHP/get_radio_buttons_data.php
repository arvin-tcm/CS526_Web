<!DOCTYPE html>
<?php
if (isset($_POST['applicant_type'])) {
    $applicant_type = $_POST['applicant_type'];
}
else {
    $applicant_type = 'local';
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="get_radio_buttons_data.php" method="post">
            <input type="radio" name="applicant_type" value="local" checked="checked">Local<br>
            <input type="radio" name="applicant_type" value="International">International<br>
            <input type="submit" value="Submit" /><br>
        </form>
        <hr>
        <?php if (isset($_POST['applicant_type'])) { ?>
        <h2>You have selected:</h2>
        <ul>
            <li><?php echo $applicant_type; ?></li>
        </ul>
        <?php } ?>
    </body>
</html>
