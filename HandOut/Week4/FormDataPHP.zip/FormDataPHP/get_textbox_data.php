<!DOCTYPE html>
<?php
if (isset($_POST['username'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $action = $_POST['action'];
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="get_textbox_data.php" method="post">
            <input type="text" name="username" value="Peter"><br>
            <input type="password" name="password"><br>
            <input type="hidden" name="action" value="login"><br>
            <input type="submit" value="Submit" /><br>
        </form>
        <hr>
        <?php if (isset($_POST['username'])) { ?>
        <h2>You have entered:</h2>
        <ul>
            <li><?php echo $username; ?></li>
            <li><?php echo $password; ?></li>
            <li><?php echo $action; ?></li>
        </ul>
        <?php } ?>
    </body>
</html>
