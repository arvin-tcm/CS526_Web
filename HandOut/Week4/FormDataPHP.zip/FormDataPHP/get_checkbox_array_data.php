<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="get_checkbox_array_data.php" method="post">
            <input type="checkbox" name="flavor[]" value="ice">Add Ice<br>
            <input type="checkbox" name="flavor[]" value="lemon">Add Lemon<br>
            <input type="checkbox" name="flavor[]" value="Coke">Add Coke<br>
            <input type="submit" value="Submit" /><br>
        </form>
        <hr>
        <?php if (isset($_POST['flavor'])) { ?>
            <?php $flavors = $_POST['flavor']; ?>
            <h2>You have selected:</h2>
            <ul>
                <?php foreach ($flavors as $flavor) : ?>
                    <li><?php echo $flavor; ?></li>
                <?php endforeach; ?>
            </ul>
        <?php } ?>
    </body>
</html>

