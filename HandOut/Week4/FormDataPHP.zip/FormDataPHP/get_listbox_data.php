<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="get_listbox_data.php" method="post">
            <select name="langs[]" size="3" multiple>
                <option value="English">English</option>
                <option value="Fench">French</option>
                <option value="Spanish">Spanish</option>
            </select>
            <input type="submit" value="Submit" /><br>
        </form>
        <hr>
        <?php if (isset($_POST['langs'])) { ?>
            <?php $langs = $_POST['langs']; ?>
            <h2>You have selected:</h2>
            <ul>
                <?php foreach ($langs as $lang) : ?>
                    <li><?php echo $lang; ?></li>
                <?php endforeach; ?>
            </ul>
        <?php } ?>
    </body>
</html>
