<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="get_textarea_data.php" method="post">
            <textarea name="comment" rows="5" cols="50">Tell us about yourself!</textarea><br>
            <input type="submit" value="Submit" /><br>
        </form>
        <hr>
        <?php if (isset($_POST['comment'])) { ?>
            <?php 
                $comment = $_POST['comment']; 
                // The htmlspecialchars converts special chars to html character entities
                $comment = htmlspecialchars($comment);
                // The nl2br is used to convert a new line char to a html <br> 
                $comment = nl2br($comment, false);
                // Using print function in an expression
                (strlen($comment) > 10)?  print 'A long comment' : print 'A short comment';
            ?>
            <h2>You commented:</h2>
            <p><?php echo $comment; ?></p>
        <?php } ?>
    </body>
</html>
