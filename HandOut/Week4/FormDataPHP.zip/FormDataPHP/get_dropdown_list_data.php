<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="get_dropdown_list_data.php" method="post">
            <select name="lang">
                <option value="English">English</option>
                <option value="Fench">French</option>
                <option value="Spanish">Spanish</option>
            </select>
            <input type="submit" value="Submit" /><br>
        </form>
        <hr>
        <?php if (isset($_POST['lang'])) { ?>
            <?php $lang = $_POST['lang']; ?>
            <h2>You have selected:</h2>
            <ul>
                <li><?php echo $lang; ?></li>
            </ul>
        <?php } ?>
    </body>
</html>
