<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Metacharacters</title>
    </head>
    <body>
        <?php
        // Matching any character
        echo preg_match('/...../', "NPU") . '<br>'; // 0
        echo preg_match('/...../', "NPU76") . '<br>'; // 1
        echo preg_match('/...../', "Peter Lee") . '<br>'; // 1
        
        // Matching charactera at the beginning or end of a string
        $URL = "http://www.npu.edu"; 
        echo preg_match("/^http/", $URL) . '<br>'; // 1 
        echo preg_match("/^https/", $URL) . '<br>'; // 0
        echo preg_match("/edu$/", $URL) . '<br>'; // 1
        echo preg_match("/com$/", $URL) . '<br>'; // 1
        ?>
    </body>
</html>
