<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Character Class</title>
    </head>
    <body>
        <?php
        // use [] to specify alternate characters that are allowed in a pattern match. 
        echo preg_match("/analy[sz]e/", "analyse") . '<br>'; // 1
        echo preg_match("/analy[sz]e/", "analyze") . '<br>'; // 1
        
        // use a hyphen metacharacter (-) to specify a range of values 
        $letterGrade = 'B';
        echo preg_match("/[A-DF]/", $letterGrade) . '<br>'; // 1
        
        // use ^ to specify optional characters to exclude in a pattern match
        echo preg_match("/[^EG-Z]/", $letterGrade) . '<br>'; // 1
        echo preg_match("/[0-9]/", "5") . '<br>'; // 1
        echo preg_match("/[^0-9]/", "5") . '<br>'; // 0
        
        // to use character classes to create a phone number regular expression pattern
        echo preg_match("/^(1 )?(\([0-9]{3}\) )?([0-9]{3})(\-[0-9]{4})$/", "1 (555) 666-7777") . '<br>'; // 1
        
        // the e-mail validation regular expression
        $email = "peter@yahoo.com";
        echo preg_match("/^[\w-]+(\.[\w-]+)*@[\w- ]+(\.[\w-]+)*(\.[a-zA-Z]{2,})$/", $email) . '<br>'; // 1
        
        // use | to have multiple choice pattern
        echo preg_match("/\.(com|org|net)$/i", $email) . '<br>'; // 1
        ?>
    </body>
</html>
