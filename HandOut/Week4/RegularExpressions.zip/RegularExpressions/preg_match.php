<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Example of preg_match()</title>
    </head>
    <body>
        <?php
        // Create a regular expressiin
        $pattern = '/Buck/';
        $name1 = 'Carl Buck';
        $name2 = 'Peter Lee';
        
        // Search the patteen
        $match = preg_match($pattern, $name1);
        echo ($match == true)? "found Carl" : "not found Carl";
        echo '<br>';
        $match = preg_match($pattern, $name2);
        echo ($match == true)? "found Peter" : "not found Peter";
        echo '<br>';
        
        // Case-insensitive Search the patteen
        $match = preg_match('/carl/i', 'Carl Buck');
        echo ($match == true)? "found Carl" : "not found Carl";
        echo '<br>';
        ?>
    </body>
</html>
