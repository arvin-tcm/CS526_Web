<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Matching Characters</title>
    </head>
    <body>
        <?php
        echo '<strong>Matching Special Characters</strong><br>';
        $string = "© 2014 NPU. \ All student attended (10/2014).";
        $match = preg_match('/\xA9/', $string);
        echo ($match == true)? "found" : "not found";
        echo '<br>';            
        $match = preg_match('///', $string);
        echo ($match == true)? "found" : "not found";
        echo '<br>';
        $match = preg_match('/\//', $string);
        echo ($match == true)? "found" : "not found";
        echo '<br>';
        $match = preg_match('/\\\\/', $string);
        echo ($match == true)? "found" : "not found";
        echo '<br><br>';
        
        echo '<strong>Matching Types of Characters</strong><br>';
        $string = "The part number is NPU-2015";
        $match = preg_match('/NPU./', $string);
        echo ($match == true)? "found" : "not found";
        echo '<br>';
        $match = preg_match('/NPU\d/', $string);
        echo ($match == true)? "found" : "not found";
        echo '<br>';
        $match = preg_match('/NPU-\d/', $string);
        echo ($match == true)? "found" : "not found";
        echo '<br>';
        ?>
    </body>
</html>
