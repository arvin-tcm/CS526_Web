<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Quantifiers and Subexpressions</title>
    </head>
    <body>
        <?php
        // Using Quantifiers 
        $URL = "http://www.npu.edu"; 
        echo preg_match("/^https?/", $URL) . '<br>'; // 1
        echo preg_match("/.+/", 'NPU') . '<br>'; // 1
        echo preg_match("/^0*/", '012345') . '<br>'; // 1
        echo preg_match("/^0*/", '12345') . '<br>'; // 1
        echo preg_match("/ZIP: .{5}$/", " ZIP: 01562") . '<br>'; // 1
        echo preg_match("/(ZIP: .{5,10})$/", "ZIP: 01562-2607") . '<br>'; // 1
        
        // using subexpressions
        $pattern = "/^(1 )?(\(.{3}\) )?(.{3})(\-.{4})$/";
        echo preg_match($pattern, '666-7777') . '<br>'; // 1
        echo preg_match($pattern, '(555) 666-7777') . '<br>'; // 1
        echo preg_match($pattern, '1 (555) 666-7777') . '<br>'; // 1
        ?>
    </body>
</html>
