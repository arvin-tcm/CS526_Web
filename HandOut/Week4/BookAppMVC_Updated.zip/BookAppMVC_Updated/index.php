<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>My Bookstore</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
        <h1>My Bookstore</h1>
        <div id = "main">
        <h1>Main Menu</h1>
        <p><a href = "manage_book">Managing Books</a></p>
        <p><a href = "search_book">Searching Books</a></p>
        </div>
    </body>
</html>
