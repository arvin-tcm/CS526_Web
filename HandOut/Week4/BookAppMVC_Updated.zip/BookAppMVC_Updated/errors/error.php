<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Error Page</title>
    </head>
    <body>
        <div id="main">
            <h1>Error</h1>
            <p><?php echo $error; ?></p>
        </div>
    </body>
</html>
