<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>My Bookstore</title>
        <link rel="stylesheet" type="text/css" href="../style.css" />
    </head>
    <body>
        <h1>Searching Your Book</h1>
        <div id="sidebar">
            <h1>Publishers</h1>
            <ul class="nav">
                <!-- display links for all publishers -->
                <?php foreach ($publishers as $publisher) : ?>
                    <li>
                        <a href="?publisher_id=<?php echo $publisher['publisherID']; ?>">
                            <?php echo $publisher['publisherName']; ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <div id="main">
            <h1><?php echo $title; ?></h1>
            <div id="left_column">
                <p>
                    <img src="<?php echo $image_filename; ?>"
                         alt="<?php echo $image_alt; ?>" />
                </p>
            </div>

            <div id="right_column">
                <p><b>List Price:</b> $<?php echo $price; ?></p>
                <p><b>Discount:</b> <?php echo $discount_percent; ?>%</p>
                <p><b>Your Price:</b> $<?php echo $final_price; ?>
                    (You save $<?php echo $discount_amount; ?>)</p>
                <form action="<?php echo '../cart' ?>" method="post">
                    <input type="hidden" name="action" value="add" />
                    <input type="hidden" name="book_id"
                           value="<?php echo $book_id; ?>" />
                    <b>Quantity:</b>
                    <input id="quantity" type="text" name="quantity" value="1" size="2" />
                    <br /><br />
                    <input type="submit" value="Add to Cart" />
                </form>
            </div>
        </div>
        <p style="clear:both;padding:30px;"><a href="../index.php">Back to home page</a></p>
    </body>
</html>
