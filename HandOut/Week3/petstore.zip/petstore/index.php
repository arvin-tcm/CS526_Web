<?php

/* 
 * Student Info: Name=Ken Cheung, ID=1234
 * Suject: CS526_Petstore_Summer_2015
 * Author: ken
 * Filename: index.php
 * Date and Time: May 27, 2015 11:11:39 AM
 * Project Name: petstore
 */

include_once "classes/PageData.php";
    $pageData = new PageData();
    $pageData->title = "Sunny Petstorw";
    $pageData->addCSS('css/layout.css');
    $pageData->addCSS('css/navigation.css');
    $pageData->content = include_once "views/navigation.php";
    $navigationIsClicked = isset($_GET["action"]);
    if ($navigationIsClicked) {
        $fileToLoad = $_GET["action"];
    } else {
        $fileToLoad = "gallery";
    }
    $pageData->content .= include_once "views/$fileToLoad.php";
    $page = include_once "templates/page.php";
    echo $page;