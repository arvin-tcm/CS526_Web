<?php

/* 
 * Student Info: Name=Ken Cheung, ID=1234
 * Suject: CS526_Petstore_Summer_2015
 * Author: ken
 * Filename: PageData.php
 * Date and Time: May 27, 2015 11:03:03 AM
 * Project Name: petstore
 */

class PageData {
    public $title = "";
    public $content = "";
    public $css = "";
    public $embeddedStyle = "";
    
    public function addCSS($href) {
        $this->css .= "<link href='$href' rel='stylesheet' />";
    }
}
