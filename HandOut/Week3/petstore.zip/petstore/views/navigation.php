<?php

/* 
 * Student Info: Name=Ken Cheung, ID=1234
 * Suject: CS526_Petstore_Summer_2015
 * Author: ken
 * Filename: navigation.php
 * Date and Time: May 27, 2015 11:11:01 AM
 * Project Name: petstore
 */
return "
<nav>
    <a href='index.php?action=gallery'>Gallery</a>
    <a href='index.php?action=petlist'>Pet List</a>
    <a href='index.php?action=add'>Add New Pet</a>
</nav>
";
