<?php

/* 
 * Student Info: Name=Ken Cheung, ID=1234
 * Suject: CS526_Petstore_Summer_2015
 * Author: ken
 * Filename: add_form.php
 * Date and Time: May 27, 2015 11:09:39 AM
 * Project Name: petstore
 */
return "
<form method='post' action='index.php?action=add' enctype='multipart/form-data' >    
        <label>Choose a pet image to upload</label>    
        <input type='file' name='image_data' accept='image/jpeg'/><br>
        <input type='submit' value='Upload' name='new_submitted' /> 
</form>
<hr>
<form method='post' action='index.php?action=add' >    
        <h4>Add a new pet information</h4>
        Petname: <input type=text name='petname' /><br>
        Price: <input type=text name='price' /><br>
        <input type='submit' value='Add' name='new_submitted' /> 
</form>
";
