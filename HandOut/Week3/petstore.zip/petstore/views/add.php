<?php

/*
 * Student Info: Name=Ken Cheung, ID=1234
 * Suject: CS526_Petstore_Summer_2015
 * Author: ken
 * Filename: add.php
 * Date and Time: May 27, 2015 11:08:51 AM
 * Project Name: petstore
 */

$newImageSubmitted = isset($_POST['new_submitted']);
if ($newImageSubmitted) {
    $operation = $_POST['new_submitted'];
    if( $operation == 'Upload') {
        $output = upload();
    } else if ( $operation == 'Add' ) {
        $petname = $_POST['petname'];
        $price = $_POST['price'];
        $output = saveFile($petname, $price);
    }
} else {    //this runs if form was NOT submitted    
    $output = include_once "views/add_form.php";
}

return $output; //declare new function 

function upload() {
    include_once 'classes/Uploader.php';

    $uploader = new Uploader('image_data');
    $uploader->saveIn('img');
    $fileUploaded = $uploader->save();
    if ($fileUploaded) {
        $out = 'new file upkoaded';
    } else {
        $out = 'something went wrong';
    }
    $out .= "<pre>";
    $out .=print_r($_FILES, true);
    $out .= "</pre>";
    return $out;
}

function saveFile($petname, $price) {
    $file_data = "$petname,$price\n";
    $fd = fopen('pets.txt', 'a');
    if (!$fd) {
        echo "Error! Couldn't open/create the file.";
        die;
    }
    fwrite($fd, $file_data);
    fclose($fd);
    return "$petname was added";
}
