<?php
/*
 * Student Info: Name=Ken Cheung, ID=1234
 * Suject: CS526_Petstore_Summer_2015
 * Author: ken
 * Filename: petlist.php
 * Date and Time: May 27, 2015 12:00:32 PM
 * Project Name: petstore
 */

$output = "
<table> 
     <tr> 
         <th>Petname</th>  
         <th>Price</th>  
         <th>Picture</th> 
     </tr> 
";

$fn = 'pets.txt';
$fd = fopen($fn, "r");
while (!feof($fd)) {
    $fields = fgetcsv($fd);
    if( is_null( $fields ) || empty($fields[0]))  {
        break;
    }
    $output .= "<tr>";
    $src = "img/$fields[0].jpg";
    $output .= "<td>$fields[0]</td><td>$fields[1]</td><td><img src='$src' height=100 width=100 /></td>";
    $output .=  "</tr>";
}
fclose($fd);

$output .= '</table>';


return $output;
