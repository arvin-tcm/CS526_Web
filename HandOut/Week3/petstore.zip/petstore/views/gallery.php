<?php

/* 
 * Student Info: Name=Ken Cheung, ID=1234
 * Suject: CS526_Petstore_Summer_2015
 * Author: ken
 * Filename: gallery.php
 * Date and Time: May 27, 2015 11:10:26 AM
 * Project Name: petstore
 */

return showImages();

function showImages() {
    $out = "<h1>Image Gallery</h1>";
    $out .= "<ul id='images'>";
    $folder = "img";
    $filesInFolder = new DirectoryIterator($folder);
    while ($filesInFolder->valid()) {
        $file = $filesInFolder->current();
        $filename = $file->getFilename();
        $src = "$folder/$filename";
        $fileInfo = new finfo(FILEINFO_MIME_TYPE);
        $mimeType = $fileInfo->file($src);
        
        if($mimeType === "image/jpeg") {
            $out .= "<li><img src='$src' /></li>";
        }
        $filesInFolder->next();
    }
    $out .= "</ul>";
    return $out;
}