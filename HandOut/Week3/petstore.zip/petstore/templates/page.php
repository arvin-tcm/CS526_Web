<?php

/* 
 * Student Info: Name=Ken Cheung, ID=1234
 * Suject: CS526_Petstore_Summer_2015
 * Author: ken
 * Filename: page.php
 * Date and Time: May 27, 2015 11:07:21 AM
 * Project Name: petstore
 */

return "<!DOCTYPE html>
<html>
<head>
<title>$pageData->title</title>
<meta http-equiv='Content-Type' content='text/html;charset=utf-8'/>
$pageData->css
$pageData->embeddedStyle
</head>
<body>
$pageData->content
</body>
</html>";