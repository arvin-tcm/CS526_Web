<!DOCTYPE html>
<html>
    <head>
        <title>The strpos() and strchr() function</title>
    </head>
    <body>
        <?php
        $email = "peter@yahoo.com";
        echo "<pre>";
        echo "The @ is at pos " . strpos($email, '@') . "\n";
        echo "The . is at pos " . strpos($email, '.') . "\n";

        if (strpos($email, '@') !== FALSE)
            echo "The e-mail address contains a y character.\n";
        else
            echo "<p>The e-mail address does not contain a y character.\n";

        echo "The top-level domain of the e-mail address is " . strrchr($email, ".") . "\n";
        echo "</pre>";
        ?>
    </body>
</html>
