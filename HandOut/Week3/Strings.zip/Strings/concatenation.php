<html>
    <head>
        <title>String Concatenation</title>
    </head>
    <body>
        <h1>String Concatenation</h1>
        <?php
            $colors = array("read", "green", "yellow", "silver", "gold");
            $message = "Your life is coloful: ";
            foreach ($colors as $color) {
                $message .= " " . $color;
            }
            echo("<p>$message</p>");
        ?>
    </body>
</html>