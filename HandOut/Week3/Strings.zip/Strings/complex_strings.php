<html>
    <head>
        <title>Complex Syntax Strings</title>
    </head>
    <body>
        <h1>Complex Syntax Strings</h1>
        <?php
        $product = "computer";
        echo "<p>Do you want to buy a new $product?</p><br>";
        echo "<p>Do you want to buy 100 $products?</p><br>";
        echo "<p>Do you want to buy 100 {$product}s?</p><br>";
        ?>
    </body>
</html>

