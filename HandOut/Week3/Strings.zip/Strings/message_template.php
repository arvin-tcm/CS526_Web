<html>
    <head>
        <title>The strpos() and strchr() function</title>
    </head>
    <body>
        <?php
        $students = array("Peter", "Lily", "Nancy", "Tom", "Jim");
        $scores = array(99, 87, 67, 78, 87);
        $messageTemplate = "<p>Student [NAME] got [SCORE] in the midterm exam</p>";
        foreach ($students as $studentNo => $name) {
            $tempMessage = str_replace("[NAME]", $name, $messageTemplate);
            $message = str_replace("[SCORE]", $scores[$studentNo], $tempMessage);
            echo $message;
        }
        ?>
    </body>
</html>