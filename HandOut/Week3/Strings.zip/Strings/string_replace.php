<!DOCTYPE html>
<html>
    <head>
        <title>The str_replace() and substr_replace() function</title>
    </head>
    <body>
        <?php
        $email = "peter@yahoo.com";
        $newEmail = str_replace("peter", "nancy", $email);
        echo "<pre>";
        echo "The new e-mail address is $newEmail\n";
        $str = "You love NPU, and you love yourself";
        $newStr = str_replace("love", "hate", $str);
        echo "The new str is $newStr\n";
        $start = strpos($email, "y");
        $end = strpos($email, ".");
        $length = $end - $start;
        $newEmail = substr_replace($email, "gmail", $start, $length);
        echo "The new e-mail address is $newEmail\n";
        echo "</pre>";
        ?>
    </body>
</html>
