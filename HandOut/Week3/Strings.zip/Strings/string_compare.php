<!DOCTYPE html>
<html>
    <head>
        <title>The strcmp() function</title>
    </head>
    <body>
        <?php
        $string1 = "ABCDEF";
        $string2 = "ABCF";
        $result = strcmp($string1, $string2);
        if ($result > 0)
            echo "string1 is greater than string2<br />";
        else if ($result < 0)
            echo "string1 is smaller than string2<br />";
        else
            echo "They are the same<br />";
        if (strncmp($string1, $string2, 3) == 0)
            echo "They are the same for the first 3 characters<br />";
        ?>
    </body>
</html>