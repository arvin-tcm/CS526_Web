<!DOCTYPE html>
<html>
    <head>
        <title>Changing the Case of a string</title>
    </head>
    <body>
        <h1>Changing the Case of a string </h1>
        <?php
        $someText = "tHIs cOmPUter LaNguAGe iS HArD to lEaRn.";
        echo "<h1>Confusing Text</h1>\n";
        echo "ucfirst: " . ucfirst($someText) . "<br />\n";
        echo "lcfirst: " . lcfirst($someText) . "<br />\n";
        echo "ucwords: " . ucwords($someText) . "<br />\n";

        $LowercaseText = strtolower($someText);
        echo "<h1>Lowercase Text</h1>\n";
        echo "ucfirst: " . ucfirst($LowercaseText) . "<br />\n";
        echo "lcfirst: " . lcfirst($LowercaseText) . "<br />\n";
        echo "ucwords: " . ucwords($LowercaseText) . "<br />\n";
        ?>
    </body>
</html>
