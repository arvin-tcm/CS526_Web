<!DOCTYPE html>
<html>
<head>
    <title>Complex Syntax Strings</title>
</head>
<body>
    <h1>Complex Syntax Strings</h1>
    <?php
    $books = array("Java", "C++", "PHP", "JavaScript");
    $authors = array("Peter", "Lily", "Nancy", "Dave");
    $prices = array(49, 30, 55, 20);
    for ($i = 0; $i < count($books); $i++) {
        echo "<p>The book \"{$books[$i]}\" is written by {$authors[$i]} costs {$prices[$i]}</p>";
    }
    ?>
</body>
</html>
