<!DOCTYPE html>
<html>
    <head>
        <title>The str_split and explode() function</title>
    </head>
    <body>
        <?php
        $news = "Big new iPhone brings Apple more profit";
        $wordsArray = explode(" ", $news);
        foreach ($wordsArray as $word) {
            echo "$word<br />";
        }
        $codes = "000001010010011100101";
        $codesArray = str_split($codes, 3);
        foreach ($codesArray as $code) {
            echo "$code<br />";
        }
        $codesStr = implode(":", $codesArray);
        echo "$codesStr<br />";
        ?>
    </body>
</html>