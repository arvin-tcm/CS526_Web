<!DOCTYPE html>
<html>
    <head>
        <title>Counting characters and words</title>
    </head>
    <body>
        <h1>Counting characters and words</h1>
        <?php
        $courseTitle = "Advanced PHP Web Programming";
        echo "<p>The course title contains " . strlen($courseTitle) . " characters.</p>";
        echo "<p>The course title contains " . str_word_count($courseTitle) . " words.</p>";
        ?>
    </body>
</html>

