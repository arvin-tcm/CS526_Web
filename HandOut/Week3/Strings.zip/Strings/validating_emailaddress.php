<!DOCTYPE html>
<html>
    <head>
        <title>Validating email addresses</title>
    </head>
    <body>
        <?php
        $emailAddresses = array(
            "peter.lee@yahoo.com",
            "mary.tompson.mail.cisco.com",
            "john.hart@mail.invalid",
            "alan.buck@test",
            "peterli256@example.com",
            "maryti256@test",
            "mlee@example",
            "mlee@example.net",
            "king.a.deer@example.org");

        function validateAddress($Address) {
            if (strpos($Address, '@') !== FALSE && strpos($Address, '.') !== FALSE)
                return TRUE;
            else
                return FALSE;
        }

        foreach ($emailAddresses as $address) {
            if (validateAddress($address) == FALSE)
                echo "<p>The e-mail address <em>$address</em> does not appear to be valid.</p>\n";
        }
        ?>
    </body>
</html>
