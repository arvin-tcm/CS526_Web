<!DOCTYPE html>
<html>
    <head>
        <title>The strtok() function</title>
    </head>
    <body>
        <?php
        $news = "Big new iPhone brings Apple more profit";
        $word = strtok($news, " ");
        while ($word != NULL) {
            echo "$word<br />";
            $word = strtok(" ");
        }
        ?>
    </body>
</html>