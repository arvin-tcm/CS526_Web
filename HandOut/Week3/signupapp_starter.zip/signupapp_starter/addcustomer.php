
<?php


// Data validation
// get the data from the form
// Add your data validation code here






// Database operation
// Add your code to add customer info to the database






if ($result)
{
?>
   <p>
     Dear, <?php echo $fullname; ?> your account is successfully created
<?php
}
else
{
   echo "Some error occurred. Please use different email address";
}
?>
