<?php

return "
<nav>
    <a href='index.php?controller=admin&action=index'>Manage Message</a>
    <a href='index.php?controller=guest&action=index'>View Message</a>
</nav>
";
