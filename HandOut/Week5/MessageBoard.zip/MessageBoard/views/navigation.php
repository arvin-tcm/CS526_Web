<?php

return "
<nav>
    <a href='index.php?controller=admin&action=post_message'>Post New Message</a>
    <a href='index.php?controller=admin&action=sort_ascending'>Sort Subjects A-Z</a>
    <a href='index.php?controller=admin&action=sort_descending'>Sort Subjects Z-A</a>
    <a href='index.php?controller=admin&action=remove_duplicates'>Remove Duplicate Messages</a>
    <a href='index.php?controller=admin&action=delete_first'>Delete First Message</a>
</nav>
";
