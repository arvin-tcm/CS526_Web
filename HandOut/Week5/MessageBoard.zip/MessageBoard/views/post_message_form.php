<?php
return "
<form action = 'index.php?controller=admin&action=post_message' method = 'POST'>
<span style = 'font-weight:bold'>Subject:</span>
<input type = 'text' name = 'subject' value = '$Subject' />
<span style = 'font-weight:bold'>Name:</span>
<input type = 'text' name = 'name' value = '$Name' /><br />
<textarea name = 'message' rows = '6' cols = '80'>$Message</textarea><br />
<input type = 'submit' name = 'add_submitted' value = 'Post Message' />
<input type = 'reset' name = 'reset' value = 'Reset Form' />
</form>
";