<?php

$hasMessages = isset($KeyMessageArray);
if ($hasMessages === false) {
    return 'views/messages_view.php needs $KeyMessageArray';
}

$output2 = "
<table style='background-color:lightgray' border='1' width='100%'>
";
$Index = 1;
$Key = key($KeyMessageArray);
foreach ($KeyMessageArray as $Message) {
    $CurrMsg = explode("~", $Message);
    $output2 .= "<tr>";
    $output2 .= "<td width='5%' style='text-align:center; font-weight:bold'>" . $Index . "</td>";
    $output2 .= "<td width='85%'><span style='font-weight:bold'>Subject: </span> " . $Key . "<br />";
    $output2 .= "<span style='font-weight:bold'>Name: </span> " . $CurrMsg[0] . "<br />";
    $output2 .= "<span style='text-decoration:underline; font-weight:bold'>Message </span><br />" . $CurrMsg[1] . "</td>";
    if ($controller == "admin") {
        $output2 .= "<td width='10%' style='text-align:center'>"
                . "<a href='index.php?" . "controller=admin&action=delete_message&" . "message=" . ($Index - 1) . "'>"
                . "Delete This Message</a></td>";
    }
    $output2 .= "</tr>";
    ++$Index;
    $Key = key($KeyMessageArray);
    next($KeyMessageArray);
}
$output2 .= "</table>";
return $output2;
