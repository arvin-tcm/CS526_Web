<?php
include_once "models/PageData.php";

$pageData = new PageData();
$pageData->title = "Message Board";
$pageData->addCSS('css/layout.css');
$pageData->addCSS('css/navigation.css');

$pageData->content = include_once "views/navigation_front.php";
$navigationIsClicked = isset($_GET["controller"]);
if ($navigationIsClicked) {
    $controller = $_GET["controller"];
} else {
    $controller = "guest";
}
echo $controller;
$pageData->content .= include_once "controllers/$controller/index.php";
$page = include_once "views/page.php";
echo $page;
