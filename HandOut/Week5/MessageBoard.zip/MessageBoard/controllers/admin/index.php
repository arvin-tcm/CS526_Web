<?php

include_once "models/Messages.php";
if (!isset($MessageArray) || count($MessageArray) == 0)
    $output = "<p>There are no messages posted.</p>\n";
else {
    $output = include_once "views/navigation.php";
    
    $hasAction = isset($_GET["action"]);
    if ($hasAction) {
        $action = $_GET["action"];
        if ($action == "post_message") {
            $output .= include_once 'controllers/admin/post_message.php';
            return $output;
        } else if ($action == "delete_message") {
            $output .= include_once 'controllers/admin/delete_message.php';
            return $output;
        } else if ($action == "sort_ascending") {
            sortAscending();
            updateMessages();
        } else if ($action == "sort_descending") {
            sortDescending();
            updateMessages();
        } else if ($action == "remove_duplicates") {
            removeDuplicates();
            updateMessages();
        } else if ($action == "delete_first") {
            deleteFirst();
            updateMessages();
        }
    }

    $count = count($MessageArray);
    for ($i = 0; $i < $count; ++$i) {
        $CurrMsg = explode("~", $MessageArray[$i]);
        $KeyMessageArray[$CurrMsg[0]] = $CurrMsg[1] . "~" . $CurrMsg[2];
    }
    $output .= include_once 'views/messages_view.php';
}

return $output;
