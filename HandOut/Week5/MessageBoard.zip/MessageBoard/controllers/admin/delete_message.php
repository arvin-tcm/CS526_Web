<?php

include_once "models/Messages.php";

if (isset($_GET['message'])) {
   $Index = $_GET['message'];
   deleteMessage($Index);
   updateMessages();
   $output2 = "Message id: ".$Index." has been deleted.";
}

return $output2;