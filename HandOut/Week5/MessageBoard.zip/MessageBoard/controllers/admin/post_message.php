<?php

include_once "models/Messages.php";

$addSubmitted = isset($_POST['add_submitted']);
if ($addSubmitted) {
    $Subject = stripslashes($_POST['subject']);
    $Name = stripslashes($_POST['name']);
    $Message = stripslashes($_POST['message']);
    // Replace any '~' characters with '-' characters     
    $Subject = str_replace("~", "-", $Subject);
    $Name = str_replace("~", "-", $Name);
    $Message = str_replace("~", "-", $Message);

    $ExistingSubjects = array();
    $count = count($MessageArray);
    for ($i = 0; $i < $count; ++$i) {
        $CurrMsg = explode("~", $MessageArray[$i]);
        $ExistingSubjects[] = $CurrMsg[0];
    }

    if (searchMessage($Subject, $ExistingSubjects)) {
        $errorMsg = "<p>The subject you entered already exists!<br />";
        $errorMsg .= "Please enter a new subject and try again.<br />";
        $errorMsg .= "Your message was not saved.</p>";
        $Subject = "";
    } else {
        $MessageRecord = "$Subject~$Name~$Message\n";
        if (saveMessages($MessageRecord) == true) {
            $output2 =  "Your message has been saved.\n";
            return $output2;
        }
    }
} else {    //this runs if form was NOT submitted   
    $Subject = "";
    $Name = "";
    $Message = "";
}

$output2 = include_once 'views/post_message_form.php';
return $output2;


