<?php

include_once "models/Messages.php";
if (!isset($MessageArray) || count($MessageArray) == 0)
    $output = "<p>There are no messages posted.</p>\n";
else {
    $count = count($MessageArray);
    for ($i = 0; $i < $count; ++$i) {
        $CurrMsg = explode("~", $MessageArray[$i]);
        $KeyMessageArray[$CurrMsg[0]] = $CurrMsg[1] . "~" . $CurrMsg[2];
    }
    $output = include_once 'views/messages_view.php';
}

return $output;
