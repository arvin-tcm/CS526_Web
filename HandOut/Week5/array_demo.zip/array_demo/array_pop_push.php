<?php

$Numbers = array(
    "One", 
    "Two", 
    "Three", 
    "Four", 
    "Five", 
    "Six", 
    "Seven", 
    "Eight", 
    "Nine", 
    "Ten");
echo "<h2>Original Array</h2>\n";
echo "<pre>\n";
print_r($Numbers);
echo "</pre>\n";
array_pop($Numbers);
echo "<h2>Array after pop()</h2>\n";
echo "<pre>\n";
print_r($Numbers);
echo "</pre>\n";
array_push($Numbers, "Eleven", "Twelve");
echo "<h2>Array after push()</h2>\n";
echo "<pre>\n";
print_r($Numbers);
echo "</pre>\n";