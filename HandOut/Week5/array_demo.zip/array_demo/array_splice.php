<?php

$Numbers = array(
    "One", 
    "Two", 
    "Three", 
    "Four", 
    "Five", 
    "Six", 
    "Seven", 
    "Eight", 
    "Nine", 
    "Ten");
echo "<h2>Original Array</h2>\n";
echo "<pre>\n";
print_r($Numbers);
echo "</pre>\n";
array_splice($Numbers, 5, 2);
echo "<h2>Array after removing 2 elements starting at 5</h2>\n";
echo "<pre>\n";
print_r($Numbers);
echo "</pre>\n";
array_splice($Numbers, 2, 0, "Two point five");
echo "<h2>Array after inserting one element at 2.</h2>\n";
echo "<pre>\n";
print_r($Numbers);
echo "</pre>\n";
array_splice($Numbers, 6, 0, array("Six", "Seven"));
echo "<h2>Array after inserting two elements at 6.</h2>\n";
echo "<pre>\n";
print_r($Numbers);
echo "</pre>\n";