<?php

$Numbers = array(
    "One", 
    "Two", 
    "Three", 
    "Four", 
    "Five", 
    "Six", 
    "Seven", 
    "Eight", 
    "Nine", 
    "Ten");
echo "<h2>Original Array</h2>\n";
echo "<pre>\n";
print_r($Numbers);
echo "</pre>\n";
array_shift($Numbers);
echo "<h2>Array after Shifting</h2>\n";
echo "<pre>\n";
print_r($Numbers);
echo "</pre>\n";
array_unshift($Numbers, "Minus One", "Zero");
echo "<h2>Array after Unshifting</h2>\n";
echo "<pre>\n";
print_r($Numbers);
echo "</pre>\n";