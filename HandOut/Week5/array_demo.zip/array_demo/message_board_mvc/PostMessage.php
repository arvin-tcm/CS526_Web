<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Post New Message</title>
    </head>
    <body>
        <h1>Post New Message</h1>
        <hr />
        <form action = "index.php" method = "POST"> 
            <input type = "hidden" name = "action" value = "addMessage" />
            <span style = "font-weight:bold">Subject:</span>
            <input type = "text" name = "subject" value="<?php echo $Subject; ?>" />
            <span style = "font-weight:bold">Name:</span>
            <input type = "text" name = "name" value="<?php echo $Name; ?>" /><br />
            <textarea name = "message" rows = "6" cols = "80"><?php echo $Message; ?></textarea><br />
            <input type = "submit" name = "submit" value = "Post Message" />
            <input type = "reset" name = "reset" value = "Reset Form" />
        </form>
        <hr />
        <p> <a href = "index.php">View Messages</a> </p>
    </body>
</html>
