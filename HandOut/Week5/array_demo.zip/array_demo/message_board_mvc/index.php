<?php

require('Messages.php');

if (isset($_GET['action']))
    $action = $_GET['action'];
else if (isset($_POST['action']))
    $action = $_POST['action'];
else
    $action = "manageMessage";


switch ($action) {
    case 'deleteFirst':
        deleteFirst();
        updateMessages();
        break;
    case 'deleteMessage':
        if (isset($_GET['message'])) {
            $Index = $_GET['message'];
            deleteMessage($Index);
            updateMessages();
        }
        break;
    case 'removeDuplicates':
        removeDuplicates();
        updateMessages();
        break;
    case 'sortAscending':
        sortAscending();
        updateMessages();
        break;
    case 'sortDescending':
        sortDescending();
        updateMessages();
        break;
    case 'postMessage':
        $Subject = "";
        $Name = "";
        $Message = "";
        include('PostMessage.php');
        exit();
    case 'addMessage':
        $Subject = stripslashes($_POST['subject']);
        $Name = stripslashes($_POST['name']);
        $Message = stripslashes($_POST['message']);
        // Replace any '~' characters with '-' characters     
        $Subject = str_replace("~", "-", $Subject);
        $Name = str_replace("~", "-", $Name);
        $Message = str_replace("~", "-", $Message);

        $ExistingSubjects = array();
        $count = count($MessageArray);
        for ($i = 0; $i < $count; ++$i) {
            $CurrMsg = explode("~", $MessageArray[$i]);
            $ExistingSubjects[] = $CurrMsg[0];
        }

        if (searchMessage($Subject, $ExistingSubjects)) {
            echo "<p>The subject you entered already exists!<br />\n";
            echo "Please enter a new subject and try again.<br />\n";
            echo "Your message was not saved.</p>";
            $Subject = "";
        } else {
            $MessageRecord = "$Subject~$Name~$Message\n";
            if (saveMessages($MessageRecord) == true) {
                echo "Your message has been saved.\n";
                $Subject = "";
                $Message = "";
            }
        }
        include('PostMessage.php');
        exit();
}

include("ManageMessages.php");
