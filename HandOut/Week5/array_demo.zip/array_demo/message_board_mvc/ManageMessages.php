<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Message Board</title>
    </head>
    <body>
        <h1>Message Board</h1> 
        <?php
        if (!isset($MessageArray) || count($MessageArray) == 0)
            echo "<p>There are no messages posted.</p>\n";
        else {
            $MessageArray = file("MessageBoard/messages.txt");
            $count = count($MessageArray);

            for ($i = 0; $i < $count; ++$i) {
                $CurrMsg = explode("~", $MessageArray[$i]);
                $KeyMessageArray[$CurrMsg[0]] = $CurrMsg[1] . "~" . $CurrMsg[2];
            }

            echo "<table style=\"background-color:lightgray\" border=\"1\" width=\"100%\">\n";
            $Index = 1;
            $Key = key($KeyMessageArray);
            foreach ($KeyMessageArray as $Message) {
                $CurrMsg = explode("~", $Message);
                echo "<tr>\n";
                echo "<td width=\"5%\" style=\"text-align:center; font-weight:bold\">" . $Index . "</td>\n";
                echo "<td width=\"85%\"><span style=\"font-weight:bold\">Subject: </span> " . htmlentities($Key) . "<br />\n";
                echo "<span style=\"font-weight:bold\">Name: </span> " . htmlentities($CurrMsg[0]) . "<br />\n";
                echo "<span style=\"text-decoration:underline; font-weight:bold\">Message </span><br />\n" . htmlentities($CurrMsg[1]) . "</td>\n";
                echo "<td width=\"10%\" style=\"text-align:center\">"
                . "<a href='index.php?" . "action=deleteMessage&" . "message=" . ($Index - 1) . "'>"
                . "Delete This Message</a></td>\n";
                echo "</tr>\n";
                ++$Index;
                $Key = key($KeyMessageArray);
                next($KeyMessageArray);
            }
            echo "</table>\n";
        }
        ?> 
        <p> 
            <a href="?action=postMessage">Post New Message</a><br /><br />
            <a href="?action=sortAscending">Sort Subjects A-Z</a><br /><br />
            <a href="?action=sortDescending">Sort Subjects Z-A</a><br /><br />
            <a href="?action=removeDuplicates">Remove Duplicate Messages</a><br /><br />
            <a href="?action=deleteFirst">Delete First Message</a><br />
        </p> 
    </body>
</html>