<?php

if ((file_exists("MessageBoard/messages.txt")) && (filesize("MessageBoard/messages.txt") != 0)) {
    $MessageArray = file("MessageBoard/messages.txt");
} else {
    $MessageArray = array();
}

function deleteFirst() {
    global $MessageArray;
    array_shift($MessageArray);
}

function deleteMessage($index) {
    global $MessageArray;
    unset($MessageArray[$index]);
    $MessageArray = array_values($MessageArray);
}

function removeDuplicates() {
    global $MessageArray;
    $MessageArray = array_unique($MessageArray);
    $MessageArray = array_values($MessageArray);
}

function sortAscending() {
    global $MessageArray;
    sort($MessageArray);
}

function sortDescending() {
    global $MessageArray;
    rsort($MessageArray);
}

function searchMessage($Subject, $ExistingSubjects) {
    return in_array($Subject, $ExistingSubjects);
}

function saveMessages($MessageRecord) {
    $MessageFile = fopen("MessageBoard/messages.txt", "ab");
    if ($MessageFile === FALSE) {
        echo "There was an error saving your message!\n";
        return false;
    } else {
        fwrite($MessageFile, $MessageRecord);
        fclose($MessageFile);
        return true;
    }
}

function updateMessages() {
    global $MessageArray;
    if (count($MessageArray) > 0) {
        $NewMessages = implode($MessageArray);
        $MessageStore = fopen("MessageBoard/messages.txt", "wb");
        if ($MessageStore === false)
            echo "There was an error updating the message file\n";
        else {
            fwrite($MessageStore, $NewMessages);
            fclose($MessageStore);
        }
    } else
        unlink("MessageBoard/messages.txt");
}
