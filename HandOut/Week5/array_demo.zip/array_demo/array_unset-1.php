<?php

$Numbers = array(
    "One", 
    "Two", 
    "Three", 
    "Four", 
    "Five", 
    "Six", 
    "Seven", 
    "Eight", 
    "Nine", 
    "Ten");
echo "<h2>Original Array</h2>\n";
echo "<pre>\n";
print_r($Numbers);
echo "</pre>\n";
unset($Numbers[6], $Numbers[7]);
echo "<h2>Array after removing Six and Seven</h2>\n";
echo "<pre>\n";
print_r($Numbers);
echo "</pre>\n";
$Numbers = array_values($Numbers);
echo "<h2>Array after array_values()</h2>\n";
echo "<pre>\n";
print_r($Numbers);
echo "</pre>\n";