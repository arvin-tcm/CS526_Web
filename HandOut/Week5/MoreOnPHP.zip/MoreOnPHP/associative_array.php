<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$keys = array('C#', 'Java', 'PHP');
$books = array('C#' => 59.99, 'Java' => 49.99, 'PHP' => 52.99);

for($i = 0; $i < count($keys); $i++) {
    echo '$books['.$keys[$i].'] is '."{$books[$keys[$i]]} <br>";
}

echo '<br>integer keys...<br>';
$keys = array(0, 5, 10, 15, 20);
$prices = array();
$prices[0] = 56.34;
$prices[5] = 46.34;
$prices[10] = 76.34;
$prices[15] = 86.34;
$prices[20] = 96.34;

for($i = 0; $i < count($keys); $i++) {
    echo '$prices['.$keys[$i].'] is '."{$prices[$keys[$i]]} <br>";
}

echo '<br>Adding...<br>';
$keys[5] = 6;
$prices[6] = 77.77;
for($i = 0; $i < count($keys); $i++) {
    echo '$prices['.$keys[$i].'] is '."{$prices[$keys[$i]]} <br>";
}

echo '<br>Deleting...<br>';
unset($prices[5]);
for($i = 0; $i < count($keys); $i++) {
    if (isset($prices[$keys[$i]])){ 
        echo '$prices['.$keys[$i].'] is '."{$prices[$keys[$i]]} <br>";
    }
}
