<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$books = array('C#','C', 'C','Java', 'C++', 'C#', 'C', 'Java', 'Java', 'PHP', 'C');
$books_unique = array_unique($books); //C#,C,Java,C++,PHP
echo implode(',', $books_unique);   

echo '<br>';
$books_reverse = array_reverse($books_unique); //PHP,C++,Java,C,C#
echo implode(',', $books_reverse); 

echo '<br>';
$books_random = $books_reverse;
shuffle($books_random); //PHP,C++,Java,C,C#
echo implode(',', $books_random); 

echo '<br>';
$books = array('C#' => 51.99, 'PHP' => 49.99, 'JAVA' => 52.99);
$book_reverse = array_reverse($books);
print_array($book_reverse);

function print_array($books) {
    echo '<br><ul>';
    foreach ($books as $key => $price) {
        echo "<li>$key -> $price</li>";
    }
    echo '</ul>';
}
