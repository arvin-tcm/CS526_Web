<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
echo 'null == \'\' is '.(null == '').'<br>';    // true as null is coverted to the empty string
echo 'null == false is '.(null == false).'<br>'; // true as null is coverted to false
echo 'null == 0 is '.(null == 0).'<br>';     // true as null is coverted to zero
echo 'false == \'0\' is '.(false == '0').'<br>';  // true as empty strings are converted to false
echo 'true == \'false\' is '.(true == 'false').'<br>';  // true as non-empty strings are converted to true
echo '3.5 == "\n3.5 inches" is '.(3.5 == "\n3.5 inches").'<br>';  // true as the string is converted to a number and then compare
echo 'INF == \'INF\' is '.(INF == 'INF').'<br>';  // false as the 'INF' is converted to zero
echo '0 == \'\' is '.(0 == '').'<br>';       // true as the empty string is converted to zero
echo '0 == \'harry\' is '.(0 == 'harry').'<br>';  // true as any string that is not numeric is converted to zero
echo '<br>'.'<br>';

echo 'null === false is '.(null === false).'<br>';
echo '3.5 !== "\n3.5 inches" is '.(3.5 !== "\n3.5 inches").'<br>';


