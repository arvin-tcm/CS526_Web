<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$numbers = range(1, 5);
echo '<br><ul>';
foreach ($numbers as $num) {
    echo "<li>$num</li>";
}
echo '</ul>';

$numbers = range(1, 5, 2);
echo '<br><ul>';
foreach ($numbers as $num) {
    echo "<li>$num</li>";
}
echo '</ul>';

$numbers = array_fill(2, 5, 8);
echo '<br><ul>';
foreach ($numbers as $key => $num) {
    echo "<li>$key -> $num</li>";
}
echo '</ul>';

$numbers = array_pad($numbers, 10, 1);
echo '<br><ul>';
foreach ($numbers as $key => $num) {
    echo "<li>$key -> $num</li>";
}
echo '</ul>';

$numbers1 = array(10, 20);
$numbers2 = array(30, 40, 50);
$numbers = array_merge($numbers1, $numbers2);
echo implode(', ', $numbers).'<br>';

$numbers = array_slice($numbers2, 1);
echo implode(', ', $numbers).'<br>';

$numbers1 = array(10, 20, 90, 100);
array_splice($numbers1, 1, 2, $numbers2);
echo implode(', ', $numbers1).'<br>';


