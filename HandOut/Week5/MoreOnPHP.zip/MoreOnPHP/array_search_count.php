<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$numbers = array(10, 20, 30, 40, 50);
$sum = array_sum($numbers);
echo "sum = $sum".'<br>';

$books = array('C#' => 59.99, 'Java' => 49.99, 'PHP' => 52.99);
$is_found = in_array(49.99, $books); // true
echo "is_found = $is_found".'<br>';  
$is_found = in_array('49.99', $books); // true
echo "is_found = $is_found".'<br>';
$is_found = in_array('49.99', $books, true); // false
echo "is_found = $is_found".'<br>';

$key_exists = array_key_exists('Java', $books); // true
echo "key_exists = $key_exists".'<br>';
$key = array_search(49.99, $books);             // Java
echo "key = $key".'<br>';

$books = array('C#','C', 'C','Java', 'C++', 'C#', 'C', 'Java', 'Java', 'PHP', 'C');
$frequency = array_count_values($books);
echo '<br><ul>';
foreach ($frequency as $key => $occurrences) {
    echo "<li>$key -> $occurrences</li>";
}
echo '</ul>';