<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$fruit = array('orange', 'apple', 'lemon', 'peaches', 'cherries', 'strawberries', 'grapes');
sort($fruit);
echo implode(',', $fruit); //apple,cherries,grapes,lemon,orange,peaches,strawberries

echo '<br>';
$numbers = array(90, '9', 30, 40, '10');
sort($numbers, SORT_NUMERIC);
//sort($numbers, SORT_STRING);
echo implode(',', $numbers); //9,20,30,40,90
echo '<br>';
rsort($numbers, SORT_NUMERIC);
echo implode(',', $numbers); //90,40,30,20,9

$books = array('C#' => 51.99, 'PHP' => 49.99, 'Java' => 52.99);
asort($books);
print_array($books);
ksort($books);
print_array($books);
arsort($books);
print_array($books);
krsort($books);
print_array($books);

function print_array($books) {
    echo '<br><ul>';
    foreach ($books as $key => $price) {
        echo "<li>$key -> $price</li>";
    }
    echo '</ul>';
}


