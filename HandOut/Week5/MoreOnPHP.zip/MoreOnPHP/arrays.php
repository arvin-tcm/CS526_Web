<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$names = array('Nancy', 'Peter', 'David');
$names_string = "";
for ($i = 0; $i < count($names); $i++) {
    $names_string .= $names[$i].' ';
}
echo $names_string.'<br>';

$names2 = array();
$names2[0] = 'Nancy';
$names2[1] = 'Peter';
$names2[2] = 'David';
$names_string = "";
for ($i = 0; $i < count($names2); $i++) {
    $names_string .= $names2[$i].' ';
}
echo $names_string.'<br>';

unset($names2[1]);
$names_string = "";

$names3 = array_values($names2);
for ($i = 0; $i < count($names3); $i++) {
    $names_string .= $names3[$i].' ';
}
echo $names_string.'<br>';


end($names2);
$last = key($names2);
$names_string = "";
for ($i = 0; $i < count($names3); $i++) {
    if (isset($names3[$i]))
        $names_string .= $names3[$i].' ';
}
echo $names_string.'<br>';

unset($names2);


?>