<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$books = array('C#' => 59.99, 'Java' => 49.99, 'PHP' => 52.99);
echo '<ul>';
foreach ($books as $price) {
    echo "<li>$price</li>";
}
echo '</ul>';

echo '<br><ul>';
foreach ($books as $title => $price) {
    echo "<li>$title = $price</li>";
}
echo '</ul>';

$prices = array();
$prices[0] = 56.34;
$prices[5] = 46.34;
$prices[10] = 76.34;
$prices[15] = 86.34;
$prices[20] = 96.34;

unset($prices[5], $prices[15]);
echo '<br><ul>';
foreach ($prices as $key => $price) {
    echo "<li>$key = $price</li>";
}
echo '</ul>';
