<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
// Create 5 arrays of arrays
$matrix = array();
for ($i = 0; $i < 5; $i++) {
    $matrix[$i] = array();
}

// add values to each element
for ($i = 0; $i < 5; $i++) {
    for ($j = 0; $j < 5; $j++) {
        $matrix[$i][$j] = $i * 5 +$j;
    }
}

// print 5 arrays of arrays
for ($i = 0; $i < 5; $i++) {
    echo implode(',  ', $matrix[$i]);
    echo '<br>';
}
echo '<br>';
// Create a shopping cart
$items = array();
$items['id'] = 1234;
$items['name'] = 'computer';
$items['price'] = 1200;
$cart[] = $items;

$items = array();
$items['id'] = 2234;
$items['name'] = 'software';
$items['price'] = 100;
$cart[] = $items;

// print 5 arrays of arrays
for ($i = 0; $i < 2; $i++) {
    echo implode(',  ', $cart[$i]);
    echo '<br>';
}
