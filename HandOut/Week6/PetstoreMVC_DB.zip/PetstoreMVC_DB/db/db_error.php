<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Database Error Page</title>
    </head>
    <body>
        <h1>Database Error Page</h1>
        <?php
        // put your code here
        echo '<h2>'.$error_msg.'<\h2>';
        ?>
    </body>
</html>
