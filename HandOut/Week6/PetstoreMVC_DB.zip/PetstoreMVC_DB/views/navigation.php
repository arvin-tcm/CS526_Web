<?php
return "
<nav>
    <a href='index.php?action=guest/show_gallery'>Gallery</a>
    <a href='index.php?action=admin/petlist'>Pet List</a>
    <a href='index.php?action=admin/add'>Add New Pet</a>
</nav>
";
