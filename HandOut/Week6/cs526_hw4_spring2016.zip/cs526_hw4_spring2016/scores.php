<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Scores</title>
    </head>
    <body>
        <h1>Student Scores</h1>
        <form name="myForm" action="index.php" method="post">
            <h2>Enter Student Scores</h2>
            Course Number: <input type="text" name="course" value="<?php echo $course; ?>" /><br>
            Score: <input type="text" name="score" value="" /><br>
            <input type="text" name="data" hidden value="<?php echo $dataJSON; ?>" />
            <hr>
            <input type="submit" name="action" value="Home" />
            <input type="submit" name="action" value="Save Score" />
        </form>
    </body>
</html>
