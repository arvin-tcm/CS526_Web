<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
    </head>
    <body>
        <h1>Grade Book</h1>
        <form name="myForm" action="index.php" method="post" >
            <h2>Input Student Information</h2>
            <input type="submit" name="action" value="Profile" />
            <br>
            <h2>Input Student Scores</h2>
            <input type="submit" name="action" value="Scores" />
            <br>
            <h2>Display Score Summary</h2>
            <input type="submit" name="action" value="Summary" />
            <br>
            <input type="text" name="data" hidden value="<?php echo $dataJSON; ?>" />
        </form>
    </body>
</html>
