<?php

$data = new stdClass();
$data->lastname = '';
$data->firstname = '';
$data->courses = new stdClass();
$action = 'Home';

if (isset($_POST['data'])) {
    $dataJSONSingleQuote = $_POST['data'];
    $dataJSON = str_replace("'", '"', $dataJSONSingleQuote);
    $data = json_decode($dataJSON);
}
if (isset($_POST['action'])) {
    $action = $_POST['action'];
}

$dataJSON = json_encode($data);
$dataJSON = str_replace('"', "'", $dataJSON);

if ($action == 'Home') {
    include 'home.php';
} else if ($action == 'Profile') {
    include 'profile.php';
} else if ($action == 'Save Profile') {
    $data->lastname = $_POST['lastname'];
    $data->firstname = $_POST['firstname'];
    $dataJSON = json_encode($data);
    $dataJSON = str_replace('"', "'", $dataJSON);
    include 'home.php';
} else if ($action == 'Scores') {
    $course = '';
    include 'scores.php';
} else if ($action == 'Save Score') {
    $course = $_POST['course'];
    $score = $_POST['score'];
    if (!isset($data->courses->$course)) {
        $data->courses->$course = array();
    }
    array_push($data->courses->$course, $score);
    $dataJSON = json_encode($data);
    $dataJSON = str_replace('"', "'", $dataJSON);

    include 'scores.php';
} else if ($action == 'Summary') {
    $summary = array();
    foreach ($data->courses as $key => $course) {
        $sum = 0;
        $count = 0;
        $max = 0;
        $min = -1;
        foreach ($course as $score) {
            $sum += $score;
            if ($score > $max) {
                $max = $score;
            }
            if ($min == -1 || $score < $min) {
                $min = $score;
            }
            $count++;
        }
        $obj = new stdClass();
        $obj->course = $key;
        $obj->max = $max;
        $obj->min = $min;
        $obj->avg = $sum / $count;
        array_push($summary, $obj);
    }
    include 'summary.php';
}