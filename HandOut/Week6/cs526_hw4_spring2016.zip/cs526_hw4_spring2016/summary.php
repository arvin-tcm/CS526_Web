<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Summary</title>
    </head>
    <body>
        <h1>Student Score Summary</h1>
        <form name="myForm" action="index.php" method="post">
            <?php
            echo "Last Name: $data->lastname <br>";
            echo "First Name: $data->firstname <br>";
            foreach ($summary as $obj) {
                //echo "$obj->course, $obj->max, $obj->min, $obj->avg <br>";
                foreach ($obj as $prop=>$value) {
                    echo "$prop: $value, ";
                }
                echo '<br>';
            }
            ?>
            <input type="submit" name="action" value="Home" />
        </form>
    </body>
</html>
