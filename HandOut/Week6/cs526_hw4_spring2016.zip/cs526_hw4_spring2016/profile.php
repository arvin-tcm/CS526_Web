<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Profile</title>
    </head>
    <body>
        <h1>Student Information</h1>
        <form name="myForm" action="index.php" method="post">
            <h2>Enter Student Information</h2>
            Last Name: <input type="text" name="lastname" value="<?php echo $data->lastname; ?>" /><br>
            First Name: <input type="text" name="firstname" value="<?php echo $data->firstname; ?>" /><br>
            <input type="text" name="data" hidden value="<?php echo $dataJSON; ?>" />
            <hr>
            <input type="submit" name="action" value="Save Profile" />
        </form>
    </body>
</html>
